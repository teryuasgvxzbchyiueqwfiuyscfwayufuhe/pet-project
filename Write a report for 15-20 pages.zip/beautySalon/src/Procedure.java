import java.sql.*;

public class Procedure {
    private String name;
    private double price;
    static Connection connection = null;
    static PreparedStatement ps = null;
    static ResultSet rs = null;

    public Procedure(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public Procedure() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public static void connection(){
        try {
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/beautySalon", "postgres", "1079");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void insert() throws SQLException {
        connection();
        ps = connection.prepareStatement("INSERT INTO procedures (name, price) VALUES (?, ?)");
        ps.setString(1, getName());
        ps.setDouble(2, getPrice());
        ps.execute();
    }
    public static void infoAllProcedure() throws SQLException {
        connection();
        Statement st = connection.createStatement();
        rs = st.executeQuery("SELECT * FROM procedures");
        while (rs.next()){
            System.out.println("ID: " + rs.getInt("id") + ", name: "
                    + rs.getString("name") + ", price: " + rs.getDouble("price") + " tenge.");
        }
        if(Login.getCurrentUser().getRole().equals("administrator")){
            Main.forTheAdministrator();
        }else {
            Main.forTheСlient();
        }
    }
    public static void searchProcedure(String name, double price) throws SQLException {
        connection();
        String res = null;
        Statement statement = connection.createStatement();
        rs = statement.executeQuery("SELECT * FROM procedures");
        while (rs.next()){
            if(name.equals(rs.getString("name")) && price==rs.getDouble("price")){
                res = "Id: " + rs.getInt("id") + ", name: " + rs.getString("name") + ", price: " +rs.getDouble("price") + "tenge";
            }
        }
        if(res == null) {
            System.out.println("There is no such procedure!");
        }
        Main.forTheAdministrator();
    }
}
