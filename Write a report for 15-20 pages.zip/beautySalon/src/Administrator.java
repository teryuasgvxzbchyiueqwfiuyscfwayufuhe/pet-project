import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Administrator extends User{
    static Scanner in = new Scanner(System.in);

    public Administrator(String username, String password, String role) {
        super(username, password, role);
    }

    public Administrator() {
    }

    @Override
    public String toString() {
        return "Name: " + getUsername() + ", role: " + getRole();
    }

    public static void addProcedure() throws SQLException {
        System.out.println("Write the name of the procedure:");
        String name = in.next();
        System.out.println("Write the price of the procedure:");
        double price = in.nextDouble();
        Procedure procedure = new Procedure(name, price);
        procedure.insert();
        procedure.searchProcedure(name, price);
        Main.forTheAdministrator();
    }
    public static void deleteProcedure() throws SQLException {
        System.out.println("Write the ID of the procedure you want to delete");
        int id = in.nextInt();
        dropProcedure(id);
        System.out.println("You have successfully deleted the procedure!");
        Main.forTheAdministrator();
    }
    private static void dropProcedure(int id) throws SQLException {
        Procedure.connection();
        Procedure.ps = connection.prepareStatement("delete from procedures where id = ?");
        Procedure.ps.setInt(1, id);
        Procedure.ps.execute();
    }
}
